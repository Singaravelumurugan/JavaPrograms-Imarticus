package Assesment_2;

public class Question_4 {

	public static void main(String[] args) {
		 int num[] = new int[]{1,2,3,4,5,6,7,8,9};
			for(int i=0;i<num.length;i++) {
					if(num[i]%2==0) {
						System.out.print("Even: "+num[i]);
						System.out.println();
					} else {
						System.out.print("Odd: "+num[i]+" ");
					}
						
				}
	}
}
