package Assesment_2;

public class Question_2 {

	public static void main(String[] args) {
		 int num[] = new int[]{1,2,3,4,5};
		 int n=num.length;
		 System.out.println("Number of elements array :"+n);
	}

}
