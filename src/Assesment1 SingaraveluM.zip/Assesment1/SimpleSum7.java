package Assesment1;
import java.util.Scanner;
public class SimpleSum7 {

	public static void main(String[] args) {
		int A,B,C,result;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the number A: ");
		A=s.nextInt();
		System.out.println("Enter the number B: ");
		B=s.nextInt();
		System.out.println("Enter the number c: ");
		C=s.nextInt();
		result=A+B+C;
		System.out.println("Result is: "+result);
	}

}
