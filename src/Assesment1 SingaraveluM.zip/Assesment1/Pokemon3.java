package Assesment1;

public class Pokemon3 {

	public static void main(String[] args) {
				int A=4;
				int B=6;
					if(A>=B) {
						System.out.println(1);
					}else {
						System.out.println(0);
					}
	}

}
