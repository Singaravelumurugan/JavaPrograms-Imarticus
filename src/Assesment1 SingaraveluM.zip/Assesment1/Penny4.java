package Assesment1;

public class Penny4 {

	public static void main(String[] args) {
		int A=8;
		int B=5;
			if(A>=B) {
				System.out.println(A>=B);
			}else {
				System.out.println(-1);
			}
	}

}
